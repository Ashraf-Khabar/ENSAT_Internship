create definer = root@localhost trigger insert_student_trigger
    after insert
    on users
    for each row
BEGIN
    if NEW.role = 'Employee' THEN
        INSERT INTO crud_project.employers (name, UserId) VALUES (NEW.name, NEW.id);
    end if;

    if NEW.role = 'Student' THEN
        INSERT INTO crud_project.students (name, UserId) VALUES (NEW.name, NEW.id);
    end if;
END;

